const express = require("express");
const router = express.Router();
const controller = require("../controllers/payment-terms.controller");

router.post("/create", controller.create);
router.post("/update", controller.update);
router.post("/list", controller.getAll);
router.post("/single", controller.getById);
router.post("/delete", controller.delete);

module.exports = router;
